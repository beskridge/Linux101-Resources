#!/bin/bash

# This is a comment
echo "Hello world"
